package com.example.onkar.augmentedimage1;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import java.io.ByteArrayOutputStream;
import java.util.Objects;

public class Main2Activity extends AppCompatActivity {

    private Button b1;
    private Button b2;
    private ImageView v1;
    public static final int CAM_REQ=111;
    public Bitmap bitmap;
    Bitmap compressedBitmap;
    byte[] byteArray;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        //bitmap=BitmapFactory.decodeResource(getResources(),R.drawable.ic_launcher_background);
        b1=(findViewById(R.id.button));
        b2=(findViewById(R.id.button2));
        v1 =(findViewById(R.id.imageView));

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(v.getContext(),MainActivity.class);
                if(byteArray != null){
                    intent.putExtra("bytes", byteArray);
                }

                startActivity(intent);

            }
        });

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                Intent intent1 =new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intent1,CAM_REQ);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode==CAM_REQ && data!=null) {
            bitmap = (Bitmap) Objects.requireNonNull(data.getExtras()).get("data");
            v1.setImageBitmap(bitmap);

        }

        Pass(bitmap);


    }

    private void Pass(Bitmap bitmap)
    {
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG,100,stream);
        byteArray = stream.toByteArray();


    }


}
